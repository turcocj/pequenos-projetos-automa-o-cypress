# 2372-automacao-e2e-cypress
Projeto utilizado no curso de Introdução a automação e2e com Cypress 
